# EXP-02 — Disabled state

Date: 2026-11-22
Target: scap-exp02
Target IP: 10.10.20.136

## Intervention

The nginx service had previously been disabled and stopped.

## Recorded observations

- LoadState=loaded
- ActiveState=inactive
- SubState=dead
- UnitFileState=disabled
- nginx and nginx-common remained installed.
- No TCP listener was observed on port 80.
- HTTP GET /exp02.txt failed.
- curl exit status: 7
- HTTP code: 000

## OpenSCAP findings

- package_nginx_removed: fail
- service_nginx_disabled: fail
- Overall OpenSCAP exit code: 2

## OVAL investigation

The service-disabled rule referenced
oval:ssg-service_nginx_disabled:def:1.

Its criteria required either:
- the nginx package to be removed;
- nginx to be absent; or
- nginx to be inactive AND its LoadState to be masked.

The observed disabled state did not satisfy these conditions.

## Evidence limitations

The XML scan artifacts are preserved from the follow-up evaluation.
The service-state and HTTP observations above are transcribed from
the experiment session, not reconstructed original output files.

The baseline used IP 10.10.20.198, whereas this follow-up used
10.10.20.136. Both were identified as scap-exp02.
