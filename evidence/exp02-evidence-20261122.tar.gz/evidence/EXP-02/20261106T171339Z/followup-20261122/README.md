# EXP-02 — nginx hardening and service functionality

## Research question

How does applying the nginx service-hardening control affect
OpenSCAP compliance findings and legitimate HTTP functionality?

## Environment

- Operating system: Ubuntu 24.04 LTS
- Target: scap-exp02 (Proxmox VM 300)
- Baseline snapshot: exp02-running-baseline
- Compliance profile: CIS Level 1 Server
- Evaluated rules:
  - package_nginx_removed
  - service_nginx_disabled

## Results

| Measurement | Baseline | Disabled | Masked |
|---|---|---|---|
| nginx package | Installed | Installed | Installed |
| nginx runtime | Running | Inactive | Inactive |
| nginx unit state | Enabled | Disabled | Masked |
| HTTP request | 200 | Failed | Failed |
| package_nginx_removed | FAIL | FAIL | FAIL |
| service_nginx_disabled | FAIL | FAIL | PASS |

## Interpretation

Disabling and stopping nginx removed the expected HTTP
functionality but did not satisfy the service-disabled OVAL check.

Inspection of the OVAL definition revealed that the rule requires
the service to be masked and inactive, absent, or its package removed.

Masking nginx changed the service-disabled compliance result
from FAIL to PASS. HTTP functionality remained unavailable.

The observed compliance improvement and functionality loss were
distinct outcomes: functionality was already lost before masking.

## Limitations

The baseline was captured on 2026-11-06, while the disabled and
masked follow-up observations were collected on 2026-11-22.

The experiment does not prove the VM configuration remained
unchanged throughout that interval.

The baseline and follow-up used different IP addresses, but
the target hostname was verified.

No attacker-capability reduction was experimentally quantified.

The results demonstrate the behavior of the evaluated OVAL
definition and the tested system, not all possible nginx
configurations or service-management mechanisms.

See disabled/observations.md for the provenance of observations
not originally saved as independent output files.
